package ca.uwaterloo.lab2_201_07;

import java.util.Arrays;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity 
{
	//Initialize Graphics
	//Graph View
	LineGraphView graph;
	//Text Views
	TextView data;
	TextView stepTitle;
	
	Button butClear, butIncrease, butDecrease;
	float peakValue = (float)0.6;
	float troughValue = (float)-0.15;
	float upperlimit = (float)2;
	
	
	int stepCount = 0;
	int loop=0;
	double c = 40;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)  
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//New Layout
		LinearLayout layout = ((LinearLayout)findViewById(R.id.layout));
		
		//Linear Acceleration Sensor
		SensorManager sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
		Sensor Accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
		SensorEventListener AccelEventListener = new AccelerationSensor();
		sensorManager.registerListener(AccelEventListener, Accelerometer,SensorManager.SENSOR_DELAY_FASTEST);
		
		
		//Add Graph to Activity
		graph = new LineGraphView(getApplicationContext(),100,Arrays.asList("Peak","Trough","Acceleration"));
		layout.addView(graph);
		graph.setVisibility(View.VISIBLE);
		
		//Add Data (peakValues, troughValues, and linear acceleration) View
		data = new TextView(this);
		layout.addView(data);
		
		//Add Step Title to Activity
		stepTitle = new TextView(this);
		stepTitle.setText("Number of Step: " + 0);
		layout.addView(stepTitle);
	
		//Add Buttons to View
		//Clear Button
		butClear = new Button(this);
		butClear.setText("Clear");
		layout.addView(butClear);
		
		butClear.setOnClickListener(new View.OnClickListener() {
		    public void onClick(View v) {
		    	//Reset Loop, Counter and Text
		    	loop = 0;
		    	stepCount = 0;
		    	stepTitle.setText("Number of Step: "+stepCount);
		    }
		});
		
		//Increase Button
		butIncrease = new Button(this);
		butIncrease.setText("Increase");
		layout.addView(butIncrease);
		
		butIncrease.setOnClickListener(new View.OnClickListener() {
		    public void onClick(View v) {
		    	//Increase Peak Value by 0.1
		    	peakValue += 0.1;
		    }
		});
		
		//Decrease Button
		butDecrease = new Button(this);
		butDecrease.setText("Decrease");
		layout.addView(butDecrease);
		
		butDecrease.setOnClickListener(new View.OnClickListener() {
		    public void onClick(View v) {
		    	//Decrease Peak Value by 0.1
		    	peakValue -= 0.1;
		    }
		});
	}
	
	

	class AccelerationSensor implements SensorEventListener
	{
		//Array of floats with a size of 3
		float[] x= new float[3];

		@Override
		public void onSensorChanged(SensorEvent event) 
		{
			//Graph Data
			x[0] = peakValue;							//Peak
			x[1] = troughValue;							//Trough
			//Low Pass Filter
			x[2]+=(event.values[2]-x[2])/(float)c;		//Smoothed Acceleration			
			
			//Step Data
			data.setText("Peak: "+x[0]+"\nTrough: "+x[1]+"\nAcceleration: "+x[2]);
			
			if(x[2] >= peakValue && loop == 0)
			{
				loop = 1;
			}
			else if(x[2] <= troughValue  &&loop == 1)
			{
				//Add Step to counter
				loop = 0;
		    	stepCount++;
		    	stepTitle.setText("Number of Step: "+stepCount);
			}
			
			else if(x[2] > upperlimit && loop == 1)
			{
				loop = 2;
			}
			else if(x[2] < peakValue && loop == 2 && x[2] > troughValue)
			{
				loop = 0;
			}
			//Add Points to Graph
			graph.addPoint(x);
		}
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {}
	}
	
}
