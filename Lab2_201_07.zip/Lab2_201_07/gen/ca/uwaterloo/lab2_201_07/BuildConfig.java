/** Automatically generated file. DO NOT MODIFY */
package ca.uwaterloo.lab2_201_07;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}